import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = { title: 'HOSPILINK — Hospitality, seamlessly connected', description: 'One calm workspace for hotel teams and a better guest experience.' };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
