import Link from 'next/link';import {AuthForm} from '@/components/AuthForm';
export default function Signup(){return <main className="auth-wrap"><section className="form-card"><Link className="brand" href="/">HOSPI<span>LINK</span></Link><h1>Create your account.</h1><p className="muted">Your hotel's calmer way to work starts here.</p><AuthForm mode="signup"/></section></main>}
