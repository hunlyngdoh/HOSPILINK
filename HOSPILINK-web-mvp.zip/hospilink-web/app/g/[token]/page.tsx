import GuestPortal from '@/components/GuestPortal';
export default async function GuestPage({params}:{params:Promise<{token:string}>}){const {token}=await params;return <GuestPortal qrToken={token}/>}
