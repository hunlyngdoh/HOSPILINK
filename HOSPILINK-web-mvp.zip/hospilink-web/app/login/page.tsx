import Link from 'next/link';import {AuthForm} from '@/components/AuthForm';
export default function Login(){return <main className="auth-wrap"><section className="form-card"><Link className="brand" href="/">HOSPI<span>LINK</span></Link><h1>Welcome back.</h1><p className="muted">Sign in to your hotel workspace.</p><AuthForm mode="login"/></section></main>}
