# HOSPILINK web MVP

Luxury-minimal, mobile-first Next.js starter connected to the HOSPILINK Supabase project.

## Included
- Public marketing page
- Email/password sign-up and sign-in
- Hotel onboarding using `create_hotel_for_current_user`
- Owner/staff dashboard with service-request counts and recent requests
- Service request board with status updates
- Guest QR portal calling the deployed `guest-portal` Edge Function
- Supabase SSR cookie refresh middleware

## Required environment variables
Copy `.env.example` to `.env.local` and fill in the Supabase **publishable** key. The Supabase URL is already set in the example. Never put a Supabase secret/service-role key in this app.

## Run locally
1. Install Node.js 20 or newer.
2. Run `npm install`.
3. Copy `.env.example` to `.env.local` and add the publishable key.
4. Run `npm run dev` and open `http://localhost:3000`.

## Deploy
Import this folder into a GitHub repository, connect the repository to Vercel, add the two environment variables above, and deploy. Use the Vercel-provided free subdomain initially; no domain purchase is required.

## Important MVP limitations
- The guest QR portal currently treats possession of an active QR code as access to the guest request flow. It does not verify a reservation, identity, or room occupancy. Do not place QR codes where the public can misuse them; booking verification and anti-abuse controls are required before production use.
- WhatsApp Cloud API, AI concierge, Google Maps, subscription billing, staff invitations, QR creation UI, knowledge-base management and super-admin screens are not connected yet.
- Email confirmation settings depend on the Supabase Auth configuration.
- This source package has not yet been deployed to a public website or passed a full browser end-to-end test.
